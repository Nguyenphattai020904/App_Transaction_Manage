package com.example.test;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface FinnhubService {

    // Lấy thông tin giá cổ phiếu
    @GET("quote")
    Call<FinnhubResponse> getStockQuote(@Query("symbol") String symbol, @Query("token") String apiKey);


}
