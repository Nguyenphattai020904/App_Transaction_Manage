package com.example.test;

public class FinnhubResponse {
    private double c; // Current Price
    private double d; // Change in price
    private double dp; // Percentage change

    public double getCurrentPrice() {
        return c;
    }

    public double getChange() {
        return d;
    }

    public double getPercentChange() {
        return dp;
    }
}
