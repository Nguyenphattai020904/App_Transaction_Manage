package com.example.test;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class FinnhubActivity extends AppCompatActivity {

    private static final String TAG = "FinnhubActivity";
    private TextView finnhubData;
    private FinnhubService finnhubService;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finnhub);

        finnhubData = findViewById(R.id.finnhubData);

        // Initialize Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://finnhub.io/api/v1/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        finnhubService = retrofit.create(FinnhubService.class);

        // Fetch data from Finnhub API
        fetchAllData();
    }

    private void fetchAllData() {
        // List of stock symbols
        String[] stockSymbols = {
                "AAPL", "GOOGL", "MSFT", "AMZN", "TSLA", "FB", "NFLX", "NVDA", "INTC", "BABA",
                "AMD", "PYPL", "DIS", "V", "CRM", "SQ", "BA", "GE", "WMT", "INTU"
        };

        // Iterate through the stock symbols and fetch data for each
        for (String symbol : stockSymbols) {
            fetchStockData(symbol);  // Fetch stock data for each company
        }
    }

    private void fetchStockData(String symbol) {
        String apiKey = getString(R.string.finnhub_api_key);  // Use a secure storage method for API keys
        Call<FinnhubResponse> call = finnhubService.getStockQuote(symbol, apiKey);
        call.enqueue(new Callback<FinnhubResponse>() {
            @Override
            public void onResponse(Call<FinnhubResponse> call, Response<FinnhubResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    FinnhubResponse finnhubResponse = response.body();
                    String stockData = "Stock (" + symbol + "):\n" +
                            "Price: " + finnhubResponse.getCurrentPrice() + "\n" +
                            "Change: " + finnhubResponse.getChange() + "\n" +
                            "Percent Change: " + finnhubResponse.getPercentChange() + "%\n";

                    // Update UI with stock data
                    appendData(symbol, stockData, finnhubResponse.getChange());
                } else {
                    Log.e(TAG, "Stock API failed: " + response.message());
                }
            }

            @Override
            public void onFailure(Call<FinnhubResponse> call, Throwable t) {
                Log.e(TAG, "Stock API error: " + t.getMessage());
            }
        });
    }

    private void appendData(String symbol, String stockData, double priceChange) {
        // Get the container (LinearLayout) where stock data will be added
        LinearLayout stockContainer = findViewById(R.id.stockContainer);

        // Create a new TextView for the stock data
        TextView stockTextView = new TextView(this);
        stockTextView.setText(stockData);
        stockTextView.setPadding(20, 20, 20, 20);
        stockTextView.setTextSize(16);

        // Set the background color based on price change (green for increase, red for decrease)
        int borderColor = (priceChange > 0) ?
                getResources().getColor(android.R.color.holo_green_light) :
                getResources().getColor(android.R.color.holo_red_light);
        // Set the background color based on price change
        int backgroundColor = (priceChange > 0) ?
                getResources().getColor(R.color.incomeColor) :  // For increase
                getResources().getColor(R.color.accentColor);   // For decrease


        // Apply a border to the TextView dynamically
        GradientDrawable border = new GradientDrawable();
        border.setShape(GradientDrawable.RECTANGLE);
        border.setColor(backgroundColor);  // Set the background color based on price change
        border.setStroke(3, borderColor);  // Set border color based on price change
        stockTextView.setBackground(border);

        // Add the TextView to the LinearLayout container
        stockContainer.addView(stockTextView);
    }
}