package com.example.test;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditBudgetActivity extends AppCompatActivity {

    EditText etDate, etCategory, etAmount, etDescription;
    Button btnUpdate, btnDelete;
    DatabaseHelper db;
    int budgetId;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_budget);

        etDate = findViewById(R.id.etDate);
        etCategory = findViewById(R.id.etCategory);
        etAmount = findViewById(R.id.etAmount);
        etDescription = findViewById(R.id.etDescription);
        btnUpdate = findViewById(R.id.btnUpdateBudget);
        btnDelete = findViewById(R.id.btnDeleteBudget);

        db = new DatabaseHelper(this);

        // Lấy ID của ngân sách từ Intent
        budgetId = getIntent().getIntExtra("BUDGET_ID", -1);

        // Tải chi tiết ngân sách
        loadBudgetDetails();

        // Xử lý sự kiện nút cập nhật
        btnUpdate.setOnClickListener(v -> updateBudget());

        // Xử lý sự kiện nút xóa
        btnDelete.setOnClickListener(v -> deleteBudget());
    }

    private void loadBudgetDetails() {
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String username = sharedPreferences.getString("loggedInUser", "Guest");

        Cursor cursor = db.getBudgetById(username, budgetId);

        if (cursor != null && cursor.moveToFirst()) {
            int dateIndex = cursor.getColumnIndex("date");
            int categoryIndex = cursor.getColumnIndex("category");
            int amountIndex = cursor.getColumnIndex("amount");
            int descriptionIndex = cursor.getColumnIndex("description");

            if (dateIndex == -1 || categoryIndex == -1 || amountIndex == -1 || descriptionIndex == -1) {
                Toast.makeText(this, "Error: Missing columns in database", Toast.LENGTH_SHORT).show();
                return;
            }

            String date = cursor.getString(dateIndex);
            String category = cursor.getString(categoryIndex);
            double amount = cursor.getDouble(amountIndex);
            String description = cursor.getString(descriptionIndex);

            etDate.setText(date);
            etCategory.setText(category);
            etAmount.setText(String.valueOf(amount));
            etDescription.setText(description);

            cursor.close();
        } else {
            Toast.makeText(this, "Budget not found", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateBudget() {
        String date = etDate.getText().toString();
        String category = etCategory.getText().toString();
        String amountString = etAmount.getText().toString();
        String description = etDescription.getText().toString();

        if (date.isEmpty() || category.isEmpty() || amountString.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "All fields must be filled out", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double amount = Double.parseDouble(amountString);
            sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            String username = sharedPreferences.getString("loggedInUser", "Guest");

            if (db.updateBudget(budgetId, date, category, amount, description)) {
                Toast.makeText(this, "Budget updated successfully", Toast.LENGTH_SHORT).show();

                // Trả kết quả về cho BudgetActivity
                Intent resultIntent = new Intent();
                setResult(RESULT_OK, resultIntent);
                finish();
            } else {
                Toast.makeText(this, "Failed to update budget", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteBudget() {
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String username = sharedPreferences.getString("loggedInUser", "Guest");

        if (db.deleteBudget(budgetId)) {
            Toast.makeText(this, "Budget deleted successfully", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to delete budget", Toast.LENGTH_SHORT).show();
        }
    }
}
