package com.example.test;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class CustomTransactionAdapter extends ArrayAdapter<String> {

    public CustomTransactionAdapter(@NonNull Context context, ArrayList<String> transactionList) {
        super(context, 0, transactionList);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String transaction = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_list_item_1, parent, false);
        }

        TextView textView = convertView.findViewById(android.R.id.text1);
        textView.setText(transaction);

        GradientDrawable border = new GradientDrawable();
        border.setCornerRadius(10);

        // Định dạng màu sắc và viền
        if (transaction != null && transaction.startsWith("Chi:")) {
            textView.setTextColor(Color.BLACK);
            border.setStroke(2, Color.WHITE); // Viền màu đỏ
        } else if (transaction != null && transaction.startsWith("Thu:")) {
            textView.setTextColor(Color.BLACK);
            border.setStroke(2, Color.WHITE); // Viền màu xanh
        }

        convertView.setBackground(border);
        return convertView;
    }
}
