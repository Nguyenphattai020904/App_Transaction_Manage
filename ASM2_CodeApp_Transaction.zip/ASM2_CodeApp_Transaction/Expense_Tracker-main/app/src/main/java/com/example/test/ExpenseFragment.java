package com.example.test;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class ExpenseFragment extends Fragment {

    ListView lvExpense;
    DatabaseHelper db;
    ArrayList<String> expenseList;
    CustomTransactionAdapter adapter;
    SharedPreferences sharedPreferences;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_expense, container, false);

        lvExpense = view.findViewById(R.id.lvExpense);
        db = new DatabaseHelper(getContext());
        expenseList = new ArrayList<>();
        loadExpenses();

        lvExpense.setOnItemClickListener((parent, view1, position, id) -> {
            String selectedExpense = expenseList.get(position);
            Toast.makeText(getContext(), "Clicked on: " + selectedExpense, Toast.LENGTH_SHORT).show();
        });

        return view;
    }

    private void loadExpenses() {
        sharedPreferences = getContext().getSharedPreferences("UserPrefs", getContext().MODE_PRIVATE);
        String username = sharedPreferences.getString("loggedInUser", "Guest");
        expenseList.clear();

        Cursor cursor = db.getAllTransactions(username);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex("id");
                int dateIndex = cursor.getColumnIndex("date");
                int categoryIndex = cursor.getColumnIndex("category");
                int amountIndex = cursor.getColumnIndex("amount");
                int descriptionIndex = cursor.getColumnIndex("description");

                if (idIndex >= 0 && dateIndex >= 0 && categoryIndex >= 0 && amountIndex >= 0 && descriptionIndex >= 0) {
                    int id = cursor.getInt(idIndex);
                    String date = cursor.getString(dateIndex);
                    String category = cursor.getString(categoryIndex);
                    double amount = cursor.getDouble(amountIndex);
                    String description = cursor.getString(descriptionIndex);

                    // Format the transaction details
                    String transaction = "ID: " + id + "\nDate: " + date + "\nCategory: " + category +
                            "\nAmount: " + amount +" VND"  + "\nDescription: " + description;
                    expenseList.add("Chi: " + transaction);
                } else {
                    Toast.makeText(getContext(), "Error: Missing columns in database", Toast.LENGTH_SHORT).show();
                }
            } while (cursor.moveToNext());
            cursor.close();
        }

        adapter = new CustomTransactionAdapter(getContext(), expenseList);
        lvExpense.setAdapter(adapter);
    }

}
