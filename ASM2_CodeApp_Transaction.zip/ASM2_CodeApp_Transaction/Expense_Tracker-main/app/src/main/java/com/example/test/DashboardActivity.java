package com.example.test;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TreeSet;

public class DashboardActivity extends AppCompatActivity {

    private LineChart lineChart;
    private TextView tvIncome, tvExpense;
    private DatabaseHelper db;
    private SharedPreferences sharedPreferences;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        lineChart = findViewById(R.id.lineChart);
        tvIncome = findViewById(R.id.tvIncome);
        tvExpense = findViewById(R.id.tvExpense);

        db = new DatabaseHelper(this);
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String username = sharedPreferences.getString("loggedInUser", "Guest");

        setUpChart(username);
        setUpSummary(username);
    }

    private void setUpChart(String username) {
        List<Entry> incomeEntries = new ArrayList<>();
        List<Entry> expenseEntries = new ArrayList<>();

        // Fetch data and fill the entries lists
        Cursor incomeCursor = db.getAllBudgets(username);
        Cursor expenseCursor = db.getAllTransactions(username);

        if (incomeCursor != null && incomeCursor.moveToFirst()) {
            do {
                int dateIndex = incomeCursor.getColumnIndex("date");
                int amountIndex = incomeCursor.getColumnIndex("amount");

                if (dateIndex >= 0 && amountIndex >= 0) {
                    String date = incomeCursor.getString(dateIndex);
                    float amount = (float) incomeCursor.getDouble(amountIndex);
                    incomeEntries.add(new Entry(convertDateToFloat(date), amount));
                }
            } while (incomeCursor.moveToNext());
            incomeCursor.close();
        }

        if (expenseCursor != null && expenseCursor.moveToFirst()) {
            do {
                int dateIndex = expenseCursor.getColumnIndex("date");
                int amountIndex = expenseCursor.getColumnIndex("amount");

                if (dateIndex >= 0 && amountIndex >= 0) {
                    String date = expenseCursor.getString(dateIndex);
                    float amount = (float) expenseCursor.getDouble(amountIndex);
                    expenseEntries.add(new Entry(convertDateToFloat(date), amount));
                }
            } while (expenseCursor.moveToNext());
            expenseCursor.close();
        }

        LineDataSet incomeDataSet = new LineDataSet(incomeEntries, "Thu");
        incomeDataSet.setColor(getResources().getColor(R.color.incomeColor));
        incomeDataSet.setLineWidth(2f);

        LineDataSet expenseDataSet = new LineDataSet(expenseEntries, "Chi");
        expenseDataSet.setColor(getResources().getColor(R.color.red));
        expenseDataSet.setLineWidth(2f);

        LineData lineData = new LineData(incomeDataSet, expenseDataSet);
        lineChart.setData(lineData);

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(getDateLabels(incomeEntries, expenseEntries)));

        YAxis leftAxis = lineChart.getAxisLeft();
        YAxis rightAxis = lineChart.getAxisRight();
        rightAxis.setEnabled(false);

        lineChart.invalidate(); // Refresh the chart
    }

    private void setUpSummary(String username) {
        double totalIncome = 0;
        double totalExpense = 0;
        String date = "";

        Cursor incomeCursor = db.getAllBudgets(username);
        Cursor expenseCursor = db.getAllTransactions(username);

        if (incomeCursor != null && incomeCursor.moveToFirst()) {
            do {
                int dateIndex = incomeCursor.getColumnIndex("date");
                int amountIndex = incomeCursor.getColumnIndex("amount");

                if (dateIndex >= 0 && amountIndex >= 0) {
                    date = incomeCursor.getString(dateIndex);
                    totalIncome += incomeCursor.getDouble(amountIndex);
                }
            } while (incomeCursor.moveToNext());
            incomeCursor.close();
        }

        if (expenseCursor != null && expenseCursor.moveToFirst()) {
            do {
                int dateIndex = expenseCursor.getColumnIndex("date");
                int amountIndex = expenseCursor.getColumnIndex("amount");

                if (dateIndex >= 0 && amountIndex >= 0) {
                    date = expenseCursor.getString(dateIndex);
                    totalExpense += expenseCursor.getDouble(amountIndex);
                }
            } while (expenseCursor.moveToNext());
            expenseCursor.close();
        }

        tvIncome.setText("Bạn đã thu tổng: " + totalIncome + " VND đến ngày " + date + ".");
        tvExpense.setText("Bạn đã chi tổng: " + totalExpense + " VND đến ngày " + date + ".");
    }

    private float convertDateToFloat(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date dateObj = sdf.parse(date);
            return dateObj.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private String[] getDateLabels(List<? extends Entry>... entriesLists) {
        TreeSet<String> dateLabels = new TreeSet<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        for (List<? extends Entry> entries : entriesLists) {
            for (Entry entry : entries) {
                dateLabels.add(sdf.format(new Date((long) entry.getX())));
            }
        }

        return dateLabels.toArray(new String[0]);
    }
}
