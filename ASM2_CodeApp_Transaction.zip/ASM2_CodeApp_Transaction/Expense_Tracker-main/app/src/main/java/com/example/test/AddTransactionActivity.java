package com.example.test;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddTransactionActivity extends AppCompatActivity {

    EditText etDate, etCategory, etAmount, etDescription;
    Button btnSaveTransaction;
    DatabaseHelper db;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_transaction);

        etDate = findViewById(R.id.etDate);
        etCategory = findViewById(R.id.etCategory);
        etAmount = findViewById(R.id.etAmount);
        etDescription = findViewById(R.id.etDescription);
        btnSaveTransaction = findViewById(R.id.btnSave);

        db = new DatabaseHelper(this);
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);

        btnSaveTransaction.setOnClickListener(v -> saveTransaction());
    }

    private void saveTransaction() {
        String date = etDate.getText().toString();
        String category = etCategory.getText().toString();
        String amountString = etAmount.getText().toString();
        String description = etDescription.getText().toString();

        if (date.isEmpty() || category.isEmpty() || amountString.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "All fields must be filled out", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount = Double.parseDouble(amountString);
        String username = sharedPreferences.getString("loggedInUser", "Guest");

        // Kiểm tra số dư trước khi thêm giao dịch
        double currentBalance = getCurrentBalance(username);
        if (currentBalance - amount < 0) {
            Toast.makeText(this, "Vượt quá số dư hiện tại!", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean inserted = db.insertTransaction(username, date, category, amount, description);
        if (inserted) {
            Toast.makeText(this, "Transaction added successfully", Toast.LENGTH_SHORT).show();

            // Trả kết quả về cho HomeActivity
            Intent resultIntent = new Intent();
            setResult(RESULT_OK, resultIntent);
            finish();
        } else {
            Toast.makeText(this, "Error adding transaction", Toast.LENGTH_SHORT).show();
        }
    }

    private double getCurrentBalance(String username) {
        double balance = 0;

        Cursor transactions = db.getAllTransactions(username);
        Cursor budgets = db.getAllBudgets(username);

        if (budgets != null && budgets.moveToFirst()) {
            do {
                int amountIndex = budgets.getColumnIndex("amount");
                if (amountIndex >= 0) {
                    balance += budgets.getDouble(amountIndex);
                } else {
                    Toast.makeText(this, "Error: Column 'amount' not found in budgets", Toast.LENGTH_SHORT).show();
                    return 0; // Trả về 0 nếu có lỗi
                }
            } while (budgets.moveToNext());
            budgets.close();
        }

        if (transactions != null && transactions.moveToFirst()) {
            do {
                int amountIndex = transactions.getColumnIndex("amount");
                if (amountIndex >= 0) {
                    balance -= transactions.getDouble(amountIndex);
                } else {
                    Toast.makeText(this, "Error: Column 'amount' not found in transactions", Toast.LENGTH_SHORT).show();
                    return 0; // Trả về 0 nếu có lỗi
                }
            } while (transactions.moveToNext());
            transactions.close();
        }

        return balance;
    }
}
