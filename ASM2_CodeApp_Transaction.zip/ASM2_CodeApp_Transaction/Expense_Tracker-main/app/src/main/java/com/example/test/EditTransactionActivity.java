package com.example.test;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditTransactionActivity extends AppCompatActivity {

    EditText etDate, etCategory, etAmount, etDescription;
    Button btnUpdateTransaction, btnDeleteTransaction;
    DatabaseHelper db;
    SharedPreferences sharedPreferences;
    int transactionId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_transaction);

        etDate = findViewById(R.id.etDate);
        etCategory = findViewById(R.id.etCategory);
        etAmount = findViewById(R.id.etAmount);
        etDescription = findViewById(R.id.etDescription);
        btnUpdateTransaction = findViewById(R.id.btnUpdate);
        btnDeleteTransaction = findViewById(R.id.btnDelete);

        db = new DatabaseHelper(this);
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);

        Intent intent = getIntent();
        transactionId = intent.getIntExtra("TRANSACTION_ID", -1);

        loadTransactionDetails();

        btnUpdateTransaction.setOnClickListener(v -> updateTransaction());
        btnDeleteTransaction.setOnClickListener(v -> deleteTransaction());
    }

    private void loadTransactionDetails() {
        String username = sharedPreferences.getString("loggedInUser", "Guest");
        Cursor cursor = db.getTransactionById(username, transactionId);

        if (cursor != null && cursor.moveToFirst()) {
            int dateIndex = cursor.getColumnIndex("date");
            int categoryIndex = cursor.getColumnIndex("category");
            int amountIndex = cursor.getColumnIndex("amount");
            int descriptionIndex = cursor.getColumnIndex("description");

            if (dateIndex >= 0 && categoryIndex >= 0 && amountIndex >= 0 && descriptionIndex >= 0) {
                etDate.setText(cursor.getString(dateIndex));
                etCategory.setText(cursor.getString(categoryIndex));
                etAmount.setText(cursor.getString(amountIndex));
                etDescription.setText(cursor.getString(descriptionIndex));
            } else {
                Toast.makeText(this, "Error: Column not found", Toast.LENGTH_SHORT).show();
            }
            cursor.close();
        }
    }

    private void updateTransaction() {
        String date = etDate.getText().toString();
        String category = etCategory.getText().toString();
        String amountString = etAmount.getText().toString();
        String description = etDescription.getText().toString();

        if (date.isEmpty() || category.isEmpty() || amountString.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "All fields must be filled out", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount = Double.parseDouble(amountString);
        String username = sharedPreferences.getString("loggedInUser", "Guest");

        double currentBalance = getCurrentBalance(username);
        if (amount > currentBalance) {
            Toast.makeText(this, "Vượt quá số dư hiện tại. Không thể cập nhật giao dịch.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean updated = db.updateTransaction(username, transactionId, date, category, amount, description);
        if (updated) {
            Toast.makeText(this, "Transaction updated successfully", Toast.LENGTH_SHORT).show();
            Intent resultIntent = new Intent();
            setResult(RESULT_OK, resultIntent);
            finish();
        } else {
            Toast.makeText(this, "Error updating transaction", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteTransaction() {
        String username = sharedPreferences.getString("loggedInUser", "Guest");

        boolean deleted = db.deleteTransaction(username, transactionId);
        if (deleted) {
            Toast.makeText(this, "Transaction deleted successfully", Toast.LENGTH_SHORT).show();
            Intent resultIntent = new Intent();
            setResult(RESULT_OK, resultIntent);
            finish();
        } else {
            Toast.makeText(this, "Error deleting transaction", Toast.LENGTH_SHORT).show();
        }
    }

    private double getCurrentBalance(String username) {
        double balance = 0;

        Cursor transactions = db.getAllTransactions(username);
        Cursor budgets = db.getAllBudgets(username);

        if (budgets != null && budgets.moveToFirst()) {
            do {
                int amountIndex = budgets.getColumnIndex("amount");
                if (amountIndex >= 0) {
                    balance += budgets.getDouble(amountIndex);
                } else {
                    Toast.makeText(this, "Error: Column 'amount' not found in budgets", Toast.LENGTH_SHORT).show();
                    return 0; // Trả về 0 nếu có lỗi
                }
            } while (budgets.moveToNext());
            budgets.close();
        }

        if (transactions != null && transactions.moveToFirst()) {
            do {
                int amountIndex = transactions.getColumnIndex("amount");
                if (amountIndex >= 0) {
                    balance -= transactions.getDouble(amountIndex);
                } else {
                    Toast.makeText(this, "Error: Column 'amount' not found in transactions", Toast.LENGTH_SHORT).show();
                    return 0; // Trả về 0 nếu có lỗi
                }
            } while (transactions.moveToNext());
            transactions.close();
        }

        return balance;
    }
}
