package com.example.test;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class BudgetActivity extends AppCompatActivity {

    ListView lvBudgets;
    Button btnAddBudget;
    DatabaseHelper db;
    ArrayList<String> budgetList;
    ArrayAdapter<String> adapter;
    SharedPreferences sharedPreferences;

    private static final int REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget);

        lvBudgets = findViewById(R.id.lvBudgets);
        btnAddBudget = findViewById(R.id.btnAddBudget);
        db = new DatabaseHelper(this);
        budgetList = new ArrayList<>();

        loadBudgets();

        // Chuyển sang AddBudgetActivity và đợi kết quả
        btnAddBudget.setOnClickListener(v -> {
            Intent intent = new Intent(BudgetActivity.this, AddBudgetActivity.class);
            startActivityForResult(intent, REQUEST_CODE);
        });

        lvBudgets.setOnItemClickListener((parent, view, position, id) -> {
            String selectedBudget = budgetList.get(position);
            int budgetId = Integer.parseInt(selectedBudget.split(":")[0]);

            new AlertDialog.Builder(this)
                    .setTitle("Manage Budget")
                    .setMessage("Choose an action")
                    .setPositiveButton("Edit", (dialog, which) -> {
                        Intent intent = new Intent(BudgetActivity.this, EditBudgetActivity.class);
                        intent.putExtra("BUDGET_ID", budgetId);
                        startActivityForResult(intent, REQUEST_CODE);
                    })
                    .setNegativeButton("Delete", (dialog, which) -> {
                        boolean deleted = db.deleteBudget(budgetId);
                        if (deleted) {
                            Toast.makeText(this, "Budget deleted", Toast.LENGTH_SHORT).show();
                            loadBudgets();
                            setResult(Activity.RESULT_OK);
                        } else {
                            Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNeutralButton("Cancel", null)
                    .show();
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            loadBudgets();
            setResult(Activity.RESULT_OK);
        }
    }

    private void loadBudgets() {
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String username = sharedPreferences.getString("loggedInUser", "Guest");
        Cursor cursor = db.getAllBudgets(username);
        budgetList.clear();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex("id");
                int dateIndex = cursor.getColumnIndex("date");
                int categoryIndex = cursor.getColumnIndex("category");
                int amountIndex = cursor.getColumnIndex("amount");
                int descriptionIndex = cursor.getColumnIndex("description");

                if (idIndex >= 0 && dateIndex >= 0 && categoryIndex >= 0 && amountIndex >= 0 && descriptionIndex >= 0) {
                    int id = cursor.getInt(idIndex);
                    String date = cursor.getString(dateIndex);
                    String category = cursor.getString(categoryIndex);
                    double amount = cursor.getDouble(amountIndex);
                    String description = cursor.getString(descriptionIndex);

                    budgetList.add(id + ": " + date + " - " + category + " - " + amount + "VND - " + description);
                } else {
                    Toast.makeText(this, "Error: Missing columns in database", Toast.LENGTH_SHORT).show();
                }
            } while (cursor.moveToNext());
            cursor.close();
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, budgetList);
        lvBudgets.setAdapter(adapter);
    }
}
