package com.example.test;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddBudgetActivity extends AppCompatActivity {

    EditText etDate, etCategory, etAmount, etDescription;
    Button btnSaveBudget;
    DatabaseHelper db;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_budget);

        etDate = findViewById(R.id.etDate);
        etCategory = findViewById(R.id.etCategory);
        etAmount = findViewById(R.id.etAmount);
        etDescription = findViewById(R.id.etDescription);
        btnSaveBudget = findViewById(R.id.btnSaveBudget);

        db = new DatabaseHelper(this);
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);

        btnSaveBudget.setOnClickListener(v -> saveBudget());
    }

    private void saveBudget() {
        String date = etDate.getText().toString();
        String category = etCategory.getText().toString();
        double amount = Double.parseDouble(etAmount.getText().toString());
        String description = etDescription.getText().toString();

        String username = sharedPreferences.getString("loggedInUser", "Guest");

        boolean inserted = db.insertBudget(username, date, category, amount, description);
        if (inserted) {
            Toast.makeText(this, "Budget added successfully", Toast.LENGTH_SHORT).show();

            // Trả kết quả về cho HomeActivity
            Intent resultIntent = new Intent();
            setResult(RESULT_OK, resultIntent);
            finish();
        } else {
            Toast.makeText(this, "Error adding budget", Toast.LENGTH_SHORT).show();
        }
    }
}
