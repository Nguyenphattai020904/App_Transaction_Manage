package com.example.test;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class IncomeFragment extends Fragment {

    ListView lvIncome;
    DatabaseHelper db;
    ArrayList<String> incomeList;
    CustomTransactionAdapter adapter;
    SharedPreferences sharedPreferences;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_income, container, false);

        lvIncome = view.findViewById(R.id.lvIncome);
        db = new DatabaseHelper(getContext());
        incomeList = new ArrayList<>();
        loadIncomes();

        lvIncome.setOnItemClickListener((parent, view1, position, id) -> {
            String selectedIncome = incomeList.get(position);
            Toast.makeText(getContext(), "Clicked on: " + selectedIncome, Toast.LENGTH_SHORT).show();
        });

        return view;
    }

    private void loadIncomes() {
        sharedPreferences = getContext().getSharedPreferences("UserPrefs", getContext().MODE_PRIVATE);
        String username = sharedPreferences.getString("loggedInUser", "Guest");
        incomeList.clear();

        Cursor cursor = db.getAllBudgets(username);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex("id");
                int dateIndex = cursor.getColumnIndex("date");
                int categoryIndex = cursor.getColumnIndex("category");
                int amountIndex = cursor.getColumnIndex("amount");
                int descriptionIndex = cursor.getColumnIndex("description");

                if (idIndex >= 0 && dateIndex >= 0 && categoryIndex >= 0 && amountIndex >= 0 && descriptionIndex >= 0) {
                    int id = cursor.getInt(idIndex);
                    String date = cursor.getString(dateIndex);
                    String category = cursor.getString(categoryIndex);
                    double amount = cursor.getDouble(amountIndex);
                    String description = cursor.getString(descriptionIndex);

                    // Format the budget details
                    String budget = "ID: " + id + "\nDate: " + date + "\nCategory: " + category +
                            "\nAmount: " + amount + " VND" + "\nDescription: " + description;
                    incomeList.add("Thu: " + budget);
                } else {
                    Toast.makeText(getContext(), "Error: Missing columns in database", Toast.LENGTH_SHORT).show();
                }
            } while (cursor.moveToNext());
            cursor.close();
        }

        adapter = new CustomTransactionAdapter(getContext(), incomeList);
        lvIncome.setAdapter(adapter);
    }

}
