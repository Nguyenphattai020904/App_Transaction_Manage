# test
 A simple Expense Tracker app built with Java in Android Studio. The app allows users to easily track their income and expenses, offering features like adding, viewing, editing, and deleting transactions. It provides a clean and intuitive interface for efficient expense management.
